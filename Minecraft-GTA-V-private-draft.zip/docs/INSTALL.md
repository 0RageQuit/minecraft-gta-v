# Installation notes

This snapshot preserves the current working mod; it is not a one-click installer.

1. Back up GTA and Minecraft settings/saves. Close both games before copying files.
2. Use GTA V Legacy Story Mode and compatible official ScriptHookV/ASI loader and ReShade with add-on support. Do not combine with GrandTheftMinecraft or another Minecraft bridge.
3. Copy `installed-build/gta/MCPassthrough.asi` and shader/configuration to the GTA directory. The ReShade runtime and shader includes must be obtained separately; inspect `gta/install.sh` for the expected runtime layout.
4. Create a dedicated Minecraft Java 26.3 Fabric instance. Install matching Fabric API and `installed-build/minecraft/mods/passthrough-0.1.0.jar`. Use JDK 25 and the Java native-access settings described in the upstream guide. Keep the dedicated world separate from normal play.
5. Run Minecraft and GTA Story Mode. The bridge uses local port 25599 and shared memory. Start with creative mode; use the current README controls.

Source: build Java under `mc/` with its Gradle wrapper and JDK 25. Build native code with `gta/build.bat` and compatible MSVC/dependencies acquired separately. Upstream build paths may need configuration; do not assume the developer's machine paths exist.

Uninstall: close games, remove the custom ASI/shader and Fabric JAR, and restore prior ReShade configuration from your backup. Keep shared loaders if other mods need them.
